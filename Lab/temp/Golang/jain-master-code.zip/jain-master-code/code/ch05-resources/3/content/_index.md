---
title: Acme Corporation
description: Welcome to the website of Acme Corporation, the leading creator of digital shapes on the planet, providing precise shape creations that are ready to use.
subtitle: shaping the *world* for you to *live in*
---

Acme Corporation&trade; is the _world's leading manufacturer of digital shapes_. From squares and circles to triangles and hexagons, we have it all. Browse through our collection of various forms with different thickness and line styles.
