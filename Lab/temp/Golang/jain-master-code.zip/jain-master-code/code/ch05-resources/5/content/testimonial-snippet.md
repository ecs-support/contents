testimonials:
  - author: Brad @ Fictional Incorporated
    content: We have been using the shapes from Acme in our products for ages. They are precise, smooth and very well built.
  - author: Random @ Random Education
    content: Sharp and sturdy - Just like you want them.
  - author: Richter @ Richter Measures
    content: Undoubted accuracy. Safety guarantee. We love what Acme delivers.
