---
title: Sample data driven page using eclectic.
content:
  - type: carousel
    title: Shapes
    items: 
      - title: Circle
        content: A plane curve everywhere equidistant from a given fixed point, the center. 
      - title: Squares
        content: A plane figure having four equal sides.
      - title: Triangle
        content: The plane figure formed by connecting three points not in a straight line by straight line segments; a three-sided polygon.
      - title: Line
        content:  A geometric figure formed by a point moving along a fixed direction and the reverse direction.
      - title: Rectangle
        content: A quadrilateral plane figure having all its angles right angles and its opposite sides consequently equal.

---
