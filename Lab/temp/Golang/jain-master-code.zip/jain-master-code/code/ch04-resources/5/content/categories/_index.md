---
title: Categories
menu:
  footer:
    weight: 3
    name: Categories
---

At Acme corporation we produce shapes and love to talk about them. Here are the various categories of content we have at Acme.
