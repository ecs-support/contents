We make over ***200 shapes***, the most popular of these include:

Shape | Design | Description | Links
---   |  ---   |   ---       | ---
Line | -- | Two pointy ends and a straight stretch of ink | [Line on wikipedia](https://en.wikipedia.org/wiki/Line_(geometry))
Circle  | &#8413; | A full round with no corners | [Circle on wikipedia]
Triangle  | &#9651; | Three lines with three corners |  [Triangle on wikipedia](https://en.wikipedia.org/wiki/Triangle)

[Circle on wikipedia]: https://en.wikipedia.org/wiki/Circle
