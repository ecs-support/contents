![](news.jpg)

<small>Image by Nick from the [Blue Diamond Gallery](http://www.thebluediamondgallery.com/handwriting/n/news.html)</small>
