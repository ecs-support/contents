Hugo In Action
===============

Chapter 2
----------

This branch contains the various resources needed for chapter 2 of Hugo in Action. You can use follow the book to build the Acme Corporation website.
