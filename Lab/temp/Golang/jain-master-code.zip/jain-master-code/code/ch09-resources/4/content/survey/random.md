---
title: Random questions from Hugo In Action
survey:
- question: Do you like websites that are slow to load?
  answer:
  - Yes
  - No
- question: Rate your confidence using Hugo to build fast websites.
  answer:
  - 1 (Very Low))
  - 2
  - 3
  - 4
  - 5
- question: What is the answer to life, the universe and everything?
- question: Any further comments.
---

Please answer a random survey we built in Hugo in Action.
