Terms And Privacy
================

Terms of use and privacy policy abstracted out of the acme corporation website.

Usage
------
```yaml
# In your config.yaml
module:
  imports:
    path: github.com/hugoinaction/TermsAndPrivacy
params:
  TermsAndPrivacy:
    company_name: <Your company>
    company_email: <contact email for your company>
    website: <Website URL>
    contact_dpo_email: <Data Protection Officer Email>
    contact_dpo_phone: <Data Protection Officer Phone number>
```


